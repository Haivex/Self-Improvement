
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "kalkulator.h"



int opcja = 0;
float a = 0;
float b = 0;
float c = 0;
float wynik = 0;


int main(void) {
	
	
	do {
		printf("Podaj numer dzialania do zrobienia: \n");
		printf("1 - dodawanie,\n");
		printf("2 - odejmowanie,\n");
		printf("3 - mnozenie,\n");
		printf("4 - dzielenie,\n");
		printf("5 - pierwiastki trojmianu,\n");
		printf("6 - modulo,\n");
		printf("7 - silnia,\n");
		printf("8 - logarytm,\n");
		printf("9 - sinus\n");
		scanf("%d", &opcja);


		if (opcja >=1 && opcja<=4)
		{
			printf("Podaj pierwsza liczbe\n");
			scanf("%g", &a);
			printf("Podaj druga liczbe\n");
			scanf("%g", &b);
		}
		//Dodawanie
		if (opcja == 1)
		{
			wynik = dodawanie(a, b);
			printf("Wynik: %g", wynik);
			printf("\n");
		}
		//Odejmowanie
		if (opcja == 2)
		{
			wynik = odejmowanie(a, b);
			printf("Wynik: %g", wynik);
			printf("\n");
		}
		//Mnozenie
		if (opcja == 3)
		{
			wynik = mnozenie(a, b);
			printf("Wynik: %g", wynik);
			printf("\n");
		}
		//Dzielenie
		if (opcja == 4)
		{
			wynik = dzielenie(a, b);
			if (b != 0)
			{
				printf("Wynik: %g", wynik);
			}
			printf("\n");
		}
		//Pierwiastki trojmianu
		if (opcja == 5)
		{
			printf("Podaj wspolczynnik a\n");
			scanf("%g", &a);
			printf("Podaj wspolczynnik b\n");
			scanf("%g", &b);
			printf("Podaj wspolczynnik c\n");
			scanf("%g", &c);
			p_trojmianu(a, b, c);
			printf("\n");
		}
		//Modulo
		if (opcja == 6)
		{
			printf("Podaj liczbe a\n");
			scanf("%g", &a);
			printf("Podaj liczbe b\n");
			scanf("%g", &b);
			wynik = modulo(a, b);
			printf("Wynik: %g", wynik);
			printf("\n");
		}
		//Silnia(podana liczba do wykonania jest ucinana do calkowitych)
		if (opcja == 7)
		{
			printf("Podaj liczbe\n");
			scanf("%g", &a);
			wynik = silnia(a);
			printf("Wynik: %g", wynik);
			printf("\n");
		}
		//Logarytm naturalny
		if (opcja == 8)
		{
			printf("Podaj liczbe\n");
			scanf("%g", &a);
			wynik = logarytm(a);
			if (a > 0)
			{
				printf("Wynik: %g", wynik);
			}
			printf("\n");
		}
		//Sinus
		if (opcja == 9)
		{
			double kat;
			double wynik_s = 0;
			int sinus_typ = 0;
			printf("W stopniach czy radianach podaj numer: \n");
			printf("1 - stopnie  \n");
			printf("2 - radiany  \n");
			scanf("%d", &sinus_typ);
			printf("Podaj liczbe\n");
			scanf("%lf", &kat);

			wynik_s = sinus(kat, sinus_typ);
			printf("Wynik: %lf", wynik_s);
			printf("\n");
		}

	} while (opcja!=0);

	//sprawdzenie czy silnia, modulo sa calkowite /* */ 

	return 0;
}

