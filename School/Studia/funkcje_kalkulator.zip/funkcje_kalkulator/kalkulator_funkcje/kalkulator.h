#pragma once
#ifndef KALKULATOR_H
#define KALKULATOR_H

float dodawanie(float a, float b);
float odejmowanie(float a, float b);
float mnozenie(float a, float b);
float dzielenie(float a, float b);
float p_trojmianu(float a, float b, float c);
unsigned long long int silnia(unsigned int a);
float logarytm(float a);
double sinus(double a, int typ);
int modulo(int a, int b);

#endif